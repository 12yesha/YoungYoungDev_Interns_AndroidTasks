package iss.workshop.memorygame;

public class Constant
{
    public static final int max_pairs = 6;
}
