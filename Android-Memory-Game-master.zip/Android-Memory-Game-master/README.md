# Android-Memory-Game
A simple memory game developed using Android studio (Java)

## Video demonstration
https://www.youtube.com/watch?v=a6kW3ojipWI
